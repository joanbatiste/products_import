<?php

declare(strict_types=1);

namespace Doctrine\DBAL\Event;

class TransactionRollBackEventArgs extends TransactionEventArgs
{
}
